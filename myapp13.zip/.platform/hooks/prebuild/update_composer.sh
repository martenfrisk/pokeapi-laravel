#!/bin/sh

# Update Composer binary.

export COMPOSER_HOME=/root

sudo /usr/bin/composer.phar self-update
